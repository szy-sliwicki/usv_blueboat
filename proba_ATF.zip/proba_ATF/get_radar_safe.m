function [dist, azimuth, elevation] = get_radar_safe(tag)
    dist = 0;
    azimuth = 0;
    elevation = 0;
    
    try
        num_targets = wb_radar_get_number_of_targets(tag);
        
        if num_targets > 0
            targets = wb_radar_get_targets(tag);
            
            min_d = inf;
            idx = 1;
            
            for i = 1:num_targets
                if targets(i).distance < min_d
                    min_d = targets(i).distance;
                    idx = i;
                end
            end
            
            dist = targets(idx).distance;
            azimuth = targets(idx).azimuth;
            elevation = targets(idx).elevation;
        end
    catch
    end
end