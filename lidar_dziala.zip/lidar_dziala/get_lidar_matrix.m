function points_matrix = get_lidar_matrix(lidar_tag, max_points)
    % Prealokacja macierzy wypełnionej wartościami NaN (Not-a-Number),
    % co jest lepsze niż same zera lub Inf dla pustych miejsc w Simulinku.
    points_matrix = NaN(max_points, 3);
    
    % Pobranie chmury punktów z Webotsa
    raw_points = wb_lidar_get_point_cloud(lidar_tag);
    
    % Sprawdzenie, ile w ogóle punktów dostaliśmy
    num_raw = length(raw_points);
    if num_raw == 0
        return; % Jeśli nic nie ma, zwróć pustą macierz (z NaN)
    end
    
    % Wyciągnięcie wszystkich punktów do tymczasowych wektorów
    temp_x = [raw_points.x]';
    temp_y = [raw_points.y]';
    temp_z = [raw_points.z]';
    
    % -------------------------------------------------------------
    % KLUCZOWY KROK: Filtrowanie
    % Znajdź indeksy tych punktów, które NIE SĄ nieskończonością (Inf)
    % i NIE SĄ wartościami nieliczbowymi (NaN).
    % -------------------------------------------------------------
    valid_mask = ~isinf(temp_x) & ~isnan(temp_x);
    
    % Wyłuskaj tylko te dobre punkty
    good_x = temp_x(valid_mask);
    good_y = temp_y(valid_mask);
    good_z = temp_z(valid_mask);
    
    % Ile dobrych punktów ostatecznie mamy?
    num_good = length(good_x);
    
    % Zabezpieczenie przed przepełnieniem macierzy w Simulinku
    limit = min(num_good, max_points);
    
    if limit > 0
        % Wpisujemy dobre punkty na samą GÓRĘ macierzy wyjściowej
        points_matrix(1:limit, 1) = good_x(1:limit);
        points_matrix(1:limit, 2) = good_y(1:limit);
        points_matrix(1:limit, 3) = good_z(1:limit);
    end
end